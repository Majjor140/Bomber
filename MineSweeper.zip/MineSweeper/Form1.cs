﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MineSweeper
{
    public partial class Form1 : Form
    {
        int [,]MineMap = new int[,] { };
        Button [,]MineButton = new Button[,] { };

        int Row = 0,
            Column = 0,
            Bombs = 0,
            Flags = 0,
            Space = 0;
        bool GameStart = false;

        public Form1()
        {
            InitializeComponent();
            //MessageBox.Show("never gonna give you up");
           // MessageBox.Show("never gonna let you down");
            //MessageBox.Show("never gonna run around and desert U");
        }

        //==============================設置地圖=================================
        void MapSet()
        {
            MineButton= new Button[Row, Column];
            MineMap = new int[Row, Column];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Column; j++)
                {
                    MineButton[i,j] = new Button();
                    MineButton[i, j].Enabled = true;
                    MineButton[i, j].Name = (i * Column + j).ToString();
                    //MineButton[i, j].Text = MineButton[i, j].Name;
                    MineButton[i, j].Location = new Point(j*25+10, 25 * i+20);
                    MineButton[i, j].Width = 25;
                    MineButton[i, j].Height = 25;
                    MineButton[i, j].Tag = 0;

                    MineButton[i, j].MouseDown += new MouseEventHandler(Sweep);

                    groupBox1.Controls.Add(MineButton[i, j]);

                    MineMap[i, j] = 0;
                }
            }
            DisplayFlag();
        }
        //==============================重置地圖=================================
        void Reset()
        {
            //MapSet();
            groupBox1.Controls.Clear();
            GameStart = false;
        }
        //==============================設置炸彈=================================
        void SetBomb()
        {
            Random rd = new Random();
            int Temp = -1;
            for(int i=0;i<Bombs;i++)
            {
                Temp = rd.Next(0, Row * Column);
                if (MineMap[Temp / Column, Temp % Column]==1||!MineButton[Temp/Column,Temp%Column].Enabled)
                {
                    i--;
                    continue;
                }

                MineMap[Temp / Column, Temp % Column] = 1;
                //MineButton[Temp / Column, Temp % Column].Text = "B";
                
            }
        }
        //==============================顯示旗子=================================
        void DisplayFlag()
        {
            if (Flags > 0)
                label4.Text = "剩餘" + Flags.ToString() + "支旗子";
            else if (Flags == 0)
                label4.Text = "已經沒有剩餘的旗子!";
            else
                label4.Text = "已超過" + (-Flags).ToString() + "支旗子";
        }
        //==============================顯示炸彈=================================
        void DisplayBomb()
        {
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Column; j++)
                {
                    if (MineMap[i, j] == 1)
                        MineButton[i, j].Text = "💣";
                }
            }
        }
        //==============================檢查事件=================================
        private void Sweep(object sender, MouseEventArgs e)
        {
            Button b = (sender as Button);
            int Number = Convert.ToInt32(b.Name);
            if (e.Button == MouseButtons.Left)
            {
                if (Convert.ToInt32(b.Tag) == 1)
                    return;

                if (MineMap[Number / Column, Number % Column] == 1)
                {
                    DisplayBomb();
                    MessageBox.Show("Boom!", "You Lose");//Debug用 
                    Reset();
                }
                else
                {   
                    SweepMine(Number/Column,Number%Column);
                }
            }

            

            if (e.Button == MouseButtons.Right)
            {
                //MessageBox.Show("Right", (sender as Button).Text);//Debug用 

                switch (b.Tag)
                {
                    case 0:
                        {
                            b.Tag = 1;
                            b.Text = "🚩";
                            Flags--;
                            break;
                        }
                    case 1:
                        {
                            b.Tag = 2;
                            b.Text = "？";
                            Flags++;
                            break;
                        }
                    case 2:
                        {
                            b.Tag = 0;
                            b.Text = "";
                            break;
                        }
                }
                DisplayFlag();
            }
        }
        //==============================掃描地雷=================================
        void SweepMine(int y,int x)
        {
            int Mine = 0;
            if (y >= Row || x >= Column || y < 0 || x < 0||!MineButton[y,x].Enabled||Convert.ToInt32(MineButton[y,x].Tag)==1)
                return;

            MineButton[y, x].Enabled = false;

            if (!GameStart)
            {
                SetBomb();
                GameStart = true;
            }

            for (int i=-1;i<2;i++)
            {
                for(int j=-1;j<2;j++)
                {
                    if (y + i >= Row || x + j >= Column || y + i < 0 || x + j < 0)
                        continue;

                    if(MineMap[y + i, x + j] == 1)
                        Mine++;
                }
            }

            if(Mine==0)
            {
                for (int i = -1; i < 2; i++)
                    for (int j = -1; j < 2; j++)
                        SweepMine(y+i, x+j);           
            }
            else
            {
                MineButton[y, x].Text = Mine.ToString();
            }

            Space--;
            if(Space==0)
            {
                DisplayBomb();
                MessageBox.Show("Win", "Win");
                Reset();
            }
        }
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("say goodbye");
            //MessageBox.Show("[rick astley] 已超出索引範圍 - on Form1 line 197","error",MessageBoxButtons.OK,MessageBoxIcon.Stop);
            try
            {
                Column = Convert.ToInt32(textBox1.Text);
                Row = Convert.ToInt32(textBox2.Text);
                Bombs = Convert.ToInt32(textBox3.Text);
                Flags = Bombs;
                Space = Column * Row - Bombs;

                if(Column<1||Row<1||Bombs<1||Bombs>=Column*Row)
                {
                    MessageBox.Show("這個數字不合理", "Warning");
                    return;
                }

                if(Row > 30 || Column > 30)
                {
                    MessageBox.Show("超標上限", "Warning");
                    return;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Warning", "這個排列組合不合理");
                return;
            }
            Reset();
            MapSet();
        }
    }
}
